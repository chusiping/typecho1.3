<?php 
return [
	'/index/{$cate}-{$page}' => '/home/index/index'
];