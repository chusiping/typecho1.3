<?php 
namespace app\home\controller;
class Index{
	
	public function index(){
		$data = \app\home\model\Index::getData();
		\mylib\View::assign($data);
		return \mylib\View::fetch();
	}
}