<!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="UTF-8">
	<title>一个简易的PHP框架！</title>
</head>
<body>
	<h1>Hello <?php echo isset($name)?$name:'World'; ?>！</h1>
</body>
</html>