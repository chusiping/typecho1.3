<?php 
namespace app\home\model;
class Index{
	
	public static function getData(){
		return [
			'name' => 'World'
		];
	}
}