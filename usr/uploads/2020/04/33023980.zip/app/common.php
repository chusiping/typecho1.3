<?php 
date_default_timezone_set('PRC');
mb_internal_encoding('UTF-8');

// 数据调试。
function p($data){
	ob_clean();
	ob_start();
	ob_implicit_flush(0);
	echo '<pre>';
	var_dump($data);
	echo '</pre>';
	flush();
	ob_flush();
}