<?php 
namespace mylib;
class Session{
	
	public static function set($name, $value){
		self::init();
		$_SESSION[self::getName($name)]=$value;
	}

	public static function get($name=null){
		self::init();
		if ($name==null) {
			$_SESSION;
		}else{
			return isset($_SESSION[self::getName($name)])?$_SESSION[self::getName($name)]:null;
		}
	}

	public static function del($name){
		self::init();
		if (isset($_SESSION[self::getName($name)])) {
			unset($_SESSION[self::getName($name)]);	
		}
	}

	public static function destroy(){
		self::init();
		session_destroy();
	}

	private static function getName($name){
		return 'xl_' . md5('xl_' . $name);
	}

	private static function init(){
		if(session_status() !== PHP_SESSION_ACTIVE){
			session_start();
		}
	}

}