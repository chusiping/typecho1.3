<?php 
namespace mylib;
class Cookie{

	public static function set($name, $value, $expire=null, $path=null, $domain=null, $secure=false){
		return setcookie(self::getName($name), $value, $expire, $path, $domain, $secure);
	}

	public static function get($name){
		return isset($_COOKIE[self::getName($name)])?$_COOKIE[self::getName($name)]:null;
	}

	public static function del($name){
		setcookie(self::getName($name), "", time()-3600);
	}

	private static function getName($name){
		return 'xl_' . md5('xl_' . $name);
	}

}