<?php 
namespace mylib;
class App{

	public static $module = 'home';
	public static $controller = 'index';
	public static $action = 'index';
	public static $param = null;

	public static function run(){
		include APP_PATH . '/common.php';
		self::initRouter();
		if (isset($_GET['s'])) {
			$_SERVER['PATH_INFO'] = $_GET['s'];
			unset($_GET['s']);
		}
		$route = \mylib\Route::parseUrl(isset($_SERVER['PATH_INFO'])?$_SERVER['PATH_INFO']:'');
		$path = explode('/', $route['path']);
		self::$module = $path[1];
		self::$controller = $path[2];
		self::$action = $path[3];
		self::$param = $route['param'];
		$class = '\\app\\' . self::$module . '\\controller\\' . self::convertUnderline(ucfirst(self::$controller));
		$res = self::exec($class, self::convertUnderline(self::$action), self::$param);
		http_response_code(200);
		echo $res;
	}

	private static function initRouter(){
		$rules = include './../config/route.php';
		foreach ($rules as $key => $value) {
			\mylib\Route::addRule($key, $value);
		}
	}

	private static function exec($class, $action, $param=null){
		if (!class_exists($class)) {
			throw new \Exception('class not found!');
		}
		$reflector = new \ReflectionClass($class);
		if (!$reflector -> hasMethod($action)) {
			throw new \Exception('action not found!');
		}
		$method = $reflector -> getMethod($action);
		if (!$method -> isPublic()) {
			throw new \Exception('action cannot invoke！');
		}
		if ($method -> isStatic()) {
			return $method -> invoke(null, $param);
		}else{
			return $method -> invoke(new $class(), $param);
		}
	}

	private static function convertUnderline($str)
	{
		return preg_replace_callback('/([-_]+([a-z]{1}))/i',function($matches){
			return strtoupper($matches[2]);
		}, $str);
	}

	private static function humpToLine($str){
		return preg_replace_callback('/([A-Z]{1})/',function($matches){
			return '_'.strtolower($matches[0]);
		}, $str);
	}
}