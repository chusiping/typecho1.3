<?php 
namespace mylib;
class View{

	protected static $data=[];

	public static function assign($key, $value=null){
		if (is_array($key)) {
			self::$data = array_merge(self::$data, $key);
		}else{
			self::$data[$key] = $value;
		}
	}

	public static function getData($key=null){
		if (is_null($key)) {
			return self::$data;
		}else{
			return isset(self::$data[$key])?self::$data[$key]:null;
		}
	}

	public static function initData(){
		self::$data = [];
	}

	public static function fetch($tpl=null, $data=null){
		ob_clean();
		ob_start();
		ob_implicit_flush(0);
		extract(self::$data);
		include $tpl ?: self::getTpl();
		flush();
		ob_flush();
		self::initData();
		return ob_get_clean();
	}

	public static function getTpl(){
		return APP_PATH . '/' . \mylib\App::$module . '/view/' . \mylib\App::$controller . '/' . \mylib\App::$action . '.php';
	}
}