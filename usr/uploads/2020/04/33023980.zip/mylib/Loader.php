<?php 
date_default_timezone_set('PRC');
require_once __DIR__.'/Autoload.php';
\mylib\Autoload::register();
\mylib\Error::register();
\mylib\App::run();