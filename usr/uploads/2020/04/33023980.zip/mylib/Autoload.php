<?php 
namespace mylib;
class Autoload{
	
	public static function register(){
		spl_autoload_register('self::my_autoload');
	}

	private static function my_autoload($class){
		$class_path = str_replace('\\', DIRECTORY_SEPARATOR, $class);
		if (0 === strpos($class_path, 'mylib')) {
			$file = dirname(__DIR__) . DIRECTORY_SEPARATOR . $class_path . '.php';
		} elseif (0 === strpos($class_path, 'app')) {
			$file = dirname(APP_PATH) . DIRECTORY_SEPARATOR . $class_path . '.php';
		} else {
			$file = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'extend' . DIRECTORY_SEPARATOR . $class_path . '.php';
		}
		if (is_file($file)) {
			require_once $file;
			if(class_exists($class, false)) {
			    return true;
			}
		}
		return false;
	}
}