<?php 
namespace mylib;
class Db{

	protected static $instances = [];

	public static function instance($dsn='', $user='', $password='', $param=[\PDO::ATTR_PERSISTENT => true,\PDO::ATTR_EMULATE_PREPARES => FALSE]){
		$key = md5($dsn . $user . $password . json_encode($param));
		if (!isset(self::$instances[$key])) {
			self::$instances[$key] = new \PDO($dsn, $user, $password);
		}
		return self::$instances[$key];
	}

}