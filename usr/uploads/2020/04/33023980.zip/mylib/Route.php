<?php 
namespace mylib;
class Route{

	protected static $routers = [];

	public static function addRule($rule, $path, $method='GET'){
		preg_match_all('/\{\$([\w]+)\}/is', $rule, $arr);
		self::$routers[] = [
			'route'=>$rule,
			'preg' => '/^' . preg_replace('/\\\{\\\\\$[\w]+\\\}/', '([\w\x{4e00}-\x{9fa5}]+)', preg_quote($rule, '/')) . '$/u',
			'path'=>$path,
			'search'=>$arr[0],
			'param'=>$arr[1],
			'method'=>$method
		];
	}

	public static function parseUrl($url){
		if (in_array($ext = pathinfo($url, PATHINFO_EXTENSION), ['html', 'php', 'shtml', 'htm', 'js', 'aspx'])) {
			$url = mb_substr($url, 0, -strlen($ext)-1);
		}
		foreach (self::$routers as $router) {
			if (preg_match($router['preg'], $url, $arr)) {
				array_shift($arr);
				return [
					'path'=>$router['path'],
					'param'=>array_combine($router['param'], $arr)
				];
			}
		}
		$p = explode('/', $url);
		array_shift($p);
		if (count($p) >= 3) {
			return [
				'path' => '/' . array_shift($p) . '/' . array_shift($p) . '/' . array_shift($p),
				'param'=> self::getParam($p)
			];
		}elseif (count($p) == 2) {
			return [
				'path' => '/home/' . ($p[0]?:'index') . '/' . ($p[1]?:'index'),
				'param'=> []
			];
		}elseif (count($p) == 1) {
			return [
				'path' => '/home/index/' . ($p[0]?:'index'),
				'param'=> []
			];
		}elseif (count($p) == 0) {
			return [
				'path' => '/home/index/index',
				'param'=> []
			];
		}
		return false;
	}

	public static function buildUrl($path, $param=[], $method='GET', $ext='.html'){
		$root = dirname($_SERVER['SCRIPT_NAME']) == '\\' ? '' : dirname($_SERVER['SCRIPT_NAME']);
		foreach (self::$routers as $value) {
			if ($value['method'] == $method && $value['path'] == $path && $value['param'] == array_keys($param)) {
				return $root . str_replace(array_values($value['search']), $param, $value['route']) . $ext;
			}
		}
		$p = '';
		foreach ($param as $key => $value) {
			$p .= $key . '/' . $value;
		}
		return $root . $path . ($p?'/' . $p:'') . $ext;
	}

	private static function getParam($p){
		if (count($p)%2) {
			$p[]=null;
		}
		$i = 0;
		$keys = [];
		$values = [];
		foreach ($p as $value) {
			if ($i%2) {
				$values[] = $value;
			}else{
				$keys[] = $value;
			}
			$i++;
		}
		return array_combine($keys, $values);
	}

}