<?php 
namespace mylib;
class Error{
	
	private static $logs = [];

	public static function register(){
		error_reporting(0);
		set_error_handler([__CLASS__, 'error_handler']);
		set_exception_handler([__CLASS__,'exception_handler']);
		register_shutdown_function([__CLASS__,'shutdown_function']);
	}

	public static function error_handler($errno, $errstr, $errfile, $errline) {
		self::record([
			'errno'=>$errno,
			'errstr'=>$errstr,
			'errfile'=>$errfile,
			'errline'=>$errline
		]);
	}

	public static function exception_handler($e) {
		self::record([
			'errno'=>$e -> getCode(),
			'errstr'=>$e -> getMessage(),
			'errfile'=>$e -> getFile(),
			'errline'=>$e -> getLine()
		]);
	}

	public static function shutdown_function() {
		$str = date('Y-m-d H:i:s', $_SERVER['REQUEST_TIME']) . ' ' . (number_format(microtime(true) - $_SERVER['REQUEST_TIME_FLOAT'], 4)) . PHP_EOL;
		$str .= $_SERVER['REQUEST_METHOD'] . ' ' . $_SERVER['REQUEST_URI'] . PHP_EOL;
		if (self::$logs) {
			foreach (self::$logs as $log) {
				$str .= '[ ' . str_pad($log['errno'], 4, ' ') . ' ] ' . $log['errstr'] . ' in ' . $log['errfile'] . ' line ' . $log['errline'] . PHP_EOL;
			}
		}
		$str .= print_r($GLOBALS, true) . PHP_EOL;
		$log_file = __DIR__ . '/../runtime/log/error.txt';
		file_put_contents($log_file, $str . PHP_EOL, FILE_APPEND);
		clearstatcache();
		if (filesize($log_file) > 10240000) {
			rename($log_file, $log_file . '.' . date('YmdHis') . '.txt');
		}
	}

	private static function record($error){
		self::$logs[] = $error;
		self::throw($error);
	}

	private static function throw($error){
		ob_clean();
		http_response_code(404);
		$tpl = <<<str
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Error!</title>
</head>
<body>
	<h1>Error!</h1>
	<p>{$error['errstr']} <b>in</b> {$error['errfile']} <b>line</b> {$error['errline']} !</p>
</body>
</html>
str;
		echo $tpl;
		exit();
	}
}